
export default async function handler(req, res) {
  const { question } = req.body;

  if (!question) {
    return res.status(400).json({ error: "No question provided" });
  }

  // Dummy response for now
  return res.status(200).json({ answer: "Dies ist eine Beispielantwort zu: " + question });
}
